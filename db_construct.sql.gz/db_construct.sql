-- MySQL dump 10.16  Distrib 10.1.17-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: cms
-- ------------------------------------------------------
-- Server version	10.1.17-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `css_styles`
--

DROP TABLE IF EXISTS `css_styles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `css_styles` (
  `id_style` int(11) DEFAULT NULL,
  `id_site` int(11) NOT NULL,
  `id_tag` int(11) DEFAULT NULL,
  `selector` varchar(255) NOT NULL,
  `style` varchar(2000) NOT NULL,
  UNIQUE KEY `id_style` (`id_style`,`id_site`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `css_styles`
--

LOCK TABLES `css_styles` WRITE;
/*!40000 ALTER TABLE `css_styles` DISABLE KEYS */;
/*!40000 ALTER TABLE `css_styles` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `next_id_style` BEFORE INSERT ON `css_styles` FOR EACH ROW BEGIN
    SET @new_id_style = (SELECT MAX(id_style) FROM css_styles WHERE id_site = NEW.id_site);
	IF @new_id_style IS NULL
    THEN
    	SET NEW.id_style = 1;
    ELSE
    	SET NEW.id_style = @new_id_style + 1;
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `html_tags`
--

DROP TABLE IF EXISTS `html_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `html_tags` (
  `id_tag` int(11) DEFAULT NULL,
  `id_site` int(11) NOT NULL,
  `parent_tag` int(11) NOT NULL DEFAULT '0',
  `index_tag` int(11) NOT NULL DEFAULT '0',
  `position_in_text` int(11) NOT NULL DEFAULT '0',
  `name` varchar(20) NOT NULL,
  `content` varchar(2000) NOT NULL,
  `selectors` varchar(1000) NOT NULL,
  UNIQUE KEY `id_tag_id_site` (`id_tag`,`id_site`) USING BTREE,
  KEY `fk_id_site` (`id_site`),
  CONSTRAINT `fk_id_site` FOREIGN KEY (`id_site`) REFERENCES `site` (`id_site`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `html_tags`
--

LOCK TABLES `html_tags` WRITE;
/*!40000 ALTER TABLE `html_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `html_tags` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `MIN_MAX_index_tag` BEFORE INSERT ON `html_tags` FOR EACH ROW BEGIN
	SET @max_index = (SELECT MAX(index_tag) FROM html_tags WHERE id_site = NEW.id_site AND parent_tag = NEW.parent_tag);
	IF NEW.index_tag > @max_index + 1
    THEN
    	SET NEW.index_tag = @max_index + 1;
    END IF;
	IF @max_index IS NULL OR NEW.index_tag < 1
    THEN
    	SET NEW.index_tag = 1;
    END IF;
    /**/
    SET @new_id_tag = (SELECT MAX(id_tag) FROM html_tags WHERE id_site = NEW.id_site);
	IF @new_id_tag IS NULL
    THEN
    	SET NEW.id_tag = 1;
    ELSE
    	SET NEW.id_tag = @new_id_tag + 1;
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `delete_style` AFTER DELETE ON `html_tags` FOR EACH ROW DELETE FROM css_styles WHERE id_site=OLD.id_site AND id_tag=OLD.id_tag */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `site`
--

DROP TABLE IF EXISTS `site`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site` (
  `id_site` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) NOT NULL,
  `sitename` varchar(100) NOT NULL,
  `title` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`id_site`),
  UNIQUE KEY `id_user` (`id_user`,`sitename`),
  KEY `fk_id_user` (`id_user`),
  CONSTRAINT `fk_id_user` FOREIGN KEY (`id_user`) REFERENCES `users` (`id_user`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `site`
--

LOCK TABLES `site` WRITE;
/*!40000 ALTER TABLE `site` DISABLE KEYS */;
/*!40000 ALTER TABLE `site` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `site_delete_style` AFTER DELETE ON `site` FOR EACH ROW DELETE FROM css_styles WHERE id_site=OLD.id_site */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id_user` int(11) NOT NULL AUTO_INCREMENT,
  `login` varchar(50) NOT NULL,
  `pass` varchar(50) NOT NULL,
  `regdate` datetime NOT NULL,
  `firstname` varchar(100) DEFAULT NULL,
  `lastname` varchar(100) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(12) DEFAULT NULL,
  PRIMARY KEY (`id_user`),
  UNIQUE KEY `login` (`login`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'alim','3ea6277babd0570c650fca3d17ec4bc5','2016-09-01 00:00:00','Алимов','Александр','a1im@mail.ru','89999999990'),(19,'sadg','202cb962ac59075b964b07152d234b70','2017-01-18 14:43:35','adgs','','',''),(20,'asdgsadg','202cb962ac59075b964b07152d234b70','2017-01-18 14:46:57','dsagsdg','','',''),(21,'alimdsg','202cb962ac59075b964b07152d234b70','2017-01-18 14:53:54','фывпыв','','',''),(22,'alim2','e3952594f28db2c40cea927d1f33260e','2017-01-18 14:59:56','asdgsdag','','',''),(23,'alim1','214be30898febafea57bf62e57db7ae3','2017-01-18 15:00:45','dasgsdg','','',''),(24,'alim3','dd6f0eb6d1329c15a0e8fa349426e6e4','2017-01-18 15:01:11','alim3','','',''),(25,'alim4','8ab411a71f7c59f92f7a7c3539614103','2017-01-18 15:02:06','124','','',''),(26,'alim5','2922e9e4d45d32f684e917b14f931ca3','2017-01-18 15:09:02','alll','','',''),(27,'a1im','f7ca0eca13d65be038ad55bb125f506c','2017-01-18 15:22:40','Саша','Алимов','a1im@mail.ru','+79030937734'),(33,'alim6','3ea6277babd0570c650fca3d17ec4bc5','2017-01-18 17:13:55','gsdf','','',''),(34,'dron','fd0e9133c7efd5ccd54f6bf79147db8f','2017-02-15 19:44:06','Andrey','','a1im@mail.ru',''),(35,'rub','8efd23a3fe0ec74453bdd0fadb91b0e3','2017-02-16 20:18:04','Рубен','','','');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-02-20 15:04:00
